import csv
import numpy as np
from nltk.tokenize import word_tokenize

print('----PLEASE USE UPPER CASE ONLY----')
c = str(input("Enter The String To Find Probablity :   "))

d = word_tokenize(c)
e = (len(d) - 1)

i = 0

datafile = open('prob_matrix2.csv', 'r', encoding="utf8")
l = list(csv.reader(datafile))

m = np.array(l)


def getMax(n):
    x = m[1:, 0]
    l5 = []
    if (n not in m):
        B = 1
        return (B)

    index = x.tolist().index(str(n))

    y = np.array(l[index + 1][1:])

    if (index > -1):
        ind = np.argpartition(y, -5)[-5:]
        viz = ind[np.argsort(y[ind])]
        print("Printing the attributes that have the highest probality of being ", n)
        rev = viz[::-1]
        store1 = []
        for i in rev:
            print(m[0, 1:][i], ":", m[index + 1, 1:][i], ' probablity')
            store2 = float((m[index + 1, 1:][i]))
            store1.append(store2)

            # for k in x:
            #     if(store2 < m[index+1,1:][k+1] ):
            #       store2= m[index+1,1:][k+1]
            #       store1.append(store2)

    # print(store1)
    # initialize lists
    test_list = store1

    # print("The original list is : " + str(test_list))

    # res_min = min(float(sub) for sub in test_list)
    res_max = max(float(sub) for sub in test_list)

    # printing result
    # print("The min value of list : " + str(res_min))
    print("The Maximum Probablity ", n, "is :" + str(res_max))


# with open('prob_matrix.csv', 'r') as fileop:
#     csv_reader = csv.DictReader(fileop)
#     for line in csv_reader:
#         a=(line['0'])
#         print("Sending" ,a)
#         getMax(a)


for x in d:
    if getMax(str(x)) == 1:
        print(x, "Not Found In Records")
        continue





