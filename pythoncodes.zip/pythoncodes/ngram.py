import csv

from nltk.tokenize import word_tokenize
count = 0
count4 = 0
ngram=[[0 for i in range(2)]for i in range(2000)]

with open('collection.csv','r') as fileop:
    csv_reader = csv.DictReader(fileop)


    for line in csv_reader:
        b = (line['s1'])
        b.lower()

        a = word_tokenize(b)
        # print(a)

        x = len(a) - 1


        for i in range(0,x):
            s = a[i] + " " + a[i+1]
            # print(s)
            ngram[count][0] = s
            count += 1
            i = i + 1

for i in ngram:
    count2 = 0
    count3 = 0
    m = str(i[0])
    j =m.split()
    u = j[0]
    z=u.lower()
    t=str(i[0])
    x=t.lower()
    for k in ngram:
        v=str(k[0])
        c = v.lower()
        p=str(k[0])
        q=p.split()
        e =q[0]
        o=e.lower()

        if(o == z  ):
            count2= count2 + 1
            #print(count2)
        if(x == c):
            count3 = count3 +1
            #print(count3)
    prob=(count3/count2)
    # print(prob)
    ngram[count4][1] = prob
    count4 = count4 + 1

for i in ngram:
    print(i)




