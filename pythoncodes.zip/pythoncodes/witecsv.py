from csv import writer

# we can use writer & dictwriter

with open('mygame.csv', 'w', newline='') as op:
    csv_writer = writer(op)
    # methods - writerow,  writerows
    csv_writer.writerow(['hell sana'])
    csv_writer.writerows([['x'],['y']])
