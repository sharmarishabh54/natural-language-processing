import csv
import numpy as np
from decimal import Decimal
import pandas as pd
from nltk.tokenize import word_tokenize

print('----PLEASE USE UPPER CASE ONLY----')
c = str(input("Enter The String To Find Probablity :   "))

d = word_tokenize(c)
e = (len(d) - 1)

i = 0

datafile = open('prob_matrix.csv', 'r')
l = list(csv.reader(datafile))

m = np.array(l)


def getMax(n):
    x = m[1:, 0]
    l5 = []
    if (n not in m):
        B = 1
        return (B)

    index = x.tolist().index(str(n))

    y = np.array(l[index + 1][1:])

    if (index > -1):
        ind = np.argpartition(y, -5)[-5:]
        viz = ind[np.argsort(y[ind])]
        print("Printing the attributes that have the highest probality of being ", n)
        rev = viz[::-1]
        store1 = []
        for i in rev:
            print(m[0, 1:][i], ":", m[index + 1, 1:][i], ' probablity')
            store2 = float((m[index + 1, 1:][i]))
            store1.append(store2)

            # for k in x:
            #     if(store2 < m[index+1,1:][k+1] ):
            #       store2= m[index+1,1:][k+1]
            #       store1.append(store2)

    # print(store1)
    # initialize lists
    test_list = store1

    # print("The original list is : " + str(test_list))

    # res_min = min(float(sub) for sub in test_list)
    res_max = max(float(sub) for sub in test_list)

    # printing result
    # print("The min value of list : " + str(res_min))
    print("The Maximum Probablity ", n, "is :" + str(res_max))


# with open('prob_matrix.csv', 'r') as fileop:
#     csv_reader = csv.DictReader(fileop)
#     for line in csv_reader:
#         a=(line['0'])
#         print("Sending" ,a)
#         getMax(a)


for x in d:
    if getMax(str(x)) == 1:
        print(x, "Not Found In Records")
        continue

"""ngram code start from here"""


import numpy as np
# print("----Please Use Upper Case only----")
# t=str(input("Please Enter The String :  "))
datafile2 = open('ngram_matrix.csv', 'r')
k = list(csv.reader(datafile2))
ngramList=np.array(k)

input=c

splitInput=input.split()
maxAtt=splitInput[0]
sent=''
rec=""
for i in range(len(splitInput)):
    maxVal=0
    rec=rec+maxAtt+" "
    st=maxAtt if i else splitInput[0]
    if(i!=(len(splitInput)-1)):
        sent=sent+st+" "
    print("Str is ",st)
    for j in splitInput:
        if(st!=j):
            try:
                index=ngramList[0:,0].tolist().index(str(st+" "+j))
                print(str(st+" "+j),index,ngramList[index][1])
                val=ngramList[index][1]
                v=float(val)
                if(v>maxVal):
                    maxVal=v
                    maxAtt=j
            except Exception as e:
                print(e)
    if(maxVal==0):
        print("Combinition not present in Ngram.Further steps not possible.")
        break
    if(i!=(len(splitInput)-1)):
        sent=sent+maxAtt+" "
        print(st+" "+maxAtt," has Maximum probability\n")
if(maxVal!=0):
    print("\nTarget phrase is:",sent,"\nAfter Removing redundancy:",rec)