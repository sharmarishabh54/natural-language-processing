import csv
import numpy as np
import pandas as pd
from csv import writer
from nltk.tokenize import word_tokenize
count = 0
ngram=[[0 for i in range(2)]for i in range(2000)]

def returnIndex(x):
    z=0
    for i in x:
        if(i=='0'):
            return z
        z=z+1
    return z

def searchList(l,a):
    try:
        return l.index(a)
    except:
        return -1

with open('collection.csv','r') as fileop:
    csv_reader = csv.DictReader(fileop)
    for line in csv_reader:
        b = (line['s1'])

        a = word_tokenize(b)
        x = len(a) - 1


        for i in range(0,x):
            s = a[i] + " " + a[i+1]
            # print(s)
            ngram[count][0] = s
            count += 1
            i = i + 1
#print(ngram)
m=np.array(ngram)
nIndex=returnIndex(m[0:,0])
npGram=m[0:nIndex,0:]
npGramAtts=np.array(m[0:nIndex,0].tolist())
print(nIndex,npGramAtts)
for i in range(len(npGramAtts)):
    n=0
    d=0
    v=npGramAtts[i].split()
    for j in range(len(npGramAtts)):
        temp=npGramAtts[j].split()
        if(v[0]==temp[0]):
            if(v[1]==temp[1]):
                n+=1
                d+=1
            else:
                d+=1
    prob=n/d
    npGram[i][1]=prob
for i in npGram:
    print(i)
pd.DataFrame(npGram).to_csv("ngram_matrix.csv", header=None, index=None)