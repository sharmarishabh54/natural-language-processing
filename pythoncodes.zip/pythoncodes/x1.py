from texttable import Texttable
import numpy as np
import pandas as pd
t=Texttable()
def returnIndex(x):
    z=0
    for i in x:
        if(i=='0'):
            return z
        z=z+1
    return z

def searchList(l,a):
    try:
        return l.index(a)
    except:
        return -1

def insertValues(setA,setB):
    splitA=setA.split()
    splitB=setB.split()
    lenA=len(splitA)
    m=np.array(l)
    indexA=returnIndex(m[0,1:])
    p=1/lenA

    for i in splitB:
        m=np.array(l)
        indexB=returnIndex(m[1:,0])
        if(searchList(m[1:indexB,0].tolist(),i)==-1):
            l[indexB+1][0]=i
    m=np.array(l)
    for i in splitA:
        m=np.array(l)
        indexA=returnIndex(m[0,1:].tolist())
        if(searchList(l[0][1:indexA],i)==-1):
            l[0][indexA+1]=i
    m=np.array(l)
    for y in splitB:
        yIndex=searchList(m[1:,0].tolist(),y)
        for x in splitA:
            xIndex=searchList(m[0][1:].tolist(),x)
            l[yIndex+1][xIndex+1]+=p
def initializeMatrix(sen,mean):
    splitSen=sen.split()
    splitMean=mean.split() 
    for i in range(len(splitSen)):
        l[0].pop(i+1)
        l[0].insert(i+1,splitSen[i])
    for i in range(len(splitMean)):
        l[i+1].pop(0)
        l[i+1].insert(0,splitMean[i])
    p=1/(len(splitSen))
    for i in range(len(splitMean)):
        for j in range(len(splitSen)):
            if(l[i+1][j+1]==0):
                l[i+1][j+1]=p
            else:
                l[i+1][j+1]+=p

def getMax(n,x):
    index=x.tolist().index(str(n))
    y=np.array(l[index+1][1:])
    if(index>-1):
        ind =np.argpartition(y, -5)[-5:]
        viz=ind[np.argsort(y[ind])]
        print("Printing the attributes that have the highest probality of being ",n)
        rev=viz[::-1]
        for i in rev:
            print(m[0,1:][i],":",m[index+1,1:][i],' probablity')

l=[[0 for i in range(1000)]for i in range(1000)]
colnames = ['collectionB', 'collectionA']
data = pd.read_csv('collection.csv', names=colnames)
collectionA=data.collectionA.tolist()
collectionB=data.collectionB.tolist()
initializeMatrix(collectionA[0],collectionB[0])
for i in range(len(collectionA)-1):
    insertValues(collectionA[i+1],collectionB[i+1])
    print("Calculated",i+1,":",collectionB[i+1],">",collectionA[i+1])

m=np.array(l)
lt=m[:returnIndex(m[1:,0])+1,:returnIndex(m[0,1:])+1]
pd.DataFrame(lt).to_csv("prob_matrix.csv", header=None, index=None)
t.add_rows(m[:returnIndex(m[1:,0])+1,:returnIndex(m[0,1:])+1])
print(t.draw())

