import csv
from decimal import Decimal
import numpy as np
print("----Please Use Upper Case only----")
t=str(input("Please Enter The String :  "))
datafile2 = open('ngram_matrix.csv', 'r')
k = list(csv.reader(datafile2))
ngramList=np.array(k)

input=t

splitInput=input.split()
maxAtt=splitInput[0]
sent=''
rec=""
for i in range(len(splitInput)):
    maxVal=0
    rec=rec+maxAtt+" "
    st=maxAtt if i else splitInput[0]
    if(i!=(len(splitInput)-1)):
        sent=sent+st+" "
    print("Str is ",st)
    for j in splitInput:
        if(st!=j):
            try:
                index=ngramList[0:,0].tolist().index(str(st+" "+j))
                print(str(st+" "+j),index,ngramList[index][1])
                val=ngramList[index][1]
                v=float(val)
                if(v>maxVal):
                    maxVal=v
                    maxAtt=j
            except Exception as e:
                print(e)
    if(maxVal==0):
        print("Combinition not present in Ngram.Further steps not possible.")
        break
    if(i!=(len(splitInput)-1)):
        sent=sent+maxAtt+" "
        print(st+" "+maxAtt," has Maximum probability\n")
if(maxVal!=0):
    print("\nTarget phrase is:",sent,"\nAfter Removing redundancy:",rec)