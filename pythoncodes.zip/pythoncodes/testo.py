import csv
with open('prob_matrix.csv', 'r') as fileop:
    csv_reader = csv.DictReader(fileop)
    for line in csv_reader:
        a=(line['0'])

